package com.example.myapplication

import android.app.Activity

import android.os.Bundle


class AttachmentActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.attachment_main)
    }
}